import { displayGroupTitle, findingKindLabel, kindLabel, severityLabel } from './labels';
import type { SavedReport } from './types';

export type ExportFormat = 'json' | 'md' | 'html' | 'pdf';

function slugBase(report: SavedReport) {
	return (report.meta.branch || 'reporte').replace(/[^a-z0-9.-]+/gi, '-') || 'reporte';
}

function escapeHtml(s: string) {
	return s
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;');
}

function triggerDownload(blob: Blob, filename: string) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement('a');
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}

/** Markdown legible para compartir o archivar el review (sin diffs crudos). */
export function buildMarkdown(report: SavedReport): string {
	const { meta, document: doc } = report;
	const lines: string[] = [];
	lines.push(`# Review: ${meta.branch || '—'} ← ${meta.base || 'develop'}`);
	lines.push('');
	if (meta.repo) lines.push(`Repo: \`${meta.repo}\``);
	lines.push(`Guardado: ${report.savedAt}`);
	lines.push('');
	lines.push('## Intención');
	lines.push('');
	lines.push(doc.intent?.trim() || '_Sin intención._');
	lines.push('');

	if (doc.notes?.length) {
		lines.push('## Notas');
		lines.push('');
		for (const n of doc.notes) lines.push(`- ${n}`);
		lines.push('');
	}

	lines.push('## Temas');
	lines.push('');
	doc.groups.forEach((g, i) => {
		const title = displayGroupTitle(g.title, g.kind);
		lines.push(`### #${i + 1} · ${kindLabel(g.kind)} — ${title}`);
		lines.push('');
		if (g.intent?.trim()) {
			lines.push(g.intent.trim());
			lines.push('');
		}
		const blocks = doc.blocks.filter((b) => b.group === g.id);
		const paths = [...new Set(blocks.map((b) => b.file))];
		if (paths.length) {
			lines.push('Archivos:');
			for (const p of paths) lines.push(`- \`${p}\``);
			lines.push('');
		}
		for (const b of blocks) {
			const loc = b.lines || (b.start && b.end ? `L${b.start}-${b.end}` : '');
			lines.push(`- **\`${b.file}\`**${loc ? ` (${loc})` : ''}: ${b.what}`);
			if (b.why?.trim()) lines.push(`  - _${b.why.trim()}_`);
		}
		if (blocks.length) lines.push('');
	});

	lines.push('## Hallazgos');
	lines.push('');
	if (!doc.findings.length) {
		lines.push('_Sin hallazgos._');
		lines.push('');
	} else {
		doc.findings.forEach((f, i) => {
			const badge = f.blocking ? 'BLOQUEA' : severityLabel(f.severity).toUpperCase();
			const loc = f.file + (f.line ? `:${f.line}` : '');
			lines.push(`### #${i + 1} · ${badge} · ${findingKindLabel(f.kind)}`);
			lines.push('');
			lines.push(`\`${loc}\` · ${f.class}`);
			lines.push('');
			lines.push(f.what);
			lines.push('');
			if (f.fix?.trim()) {
				lines.push(`**Sugerencia:** ${f.fix.trim()}`);
				lines.push('');
			}
		});
	}

	if (doc.skipped?.length) {
		lines.push('## Omitidos');
		lines.push('');
		for (const s of doc.skipped) lines.push(`- \`${s.file}\` (${s.reason})`);
		lines.push('');
	}

	return lines.join('\n');
}

/** HTML autocontenido, útil para compartir o imprimir a PDF. */
export function buildHtml(report: SavedReport): string {
	const { meta, document: doc } = report;
	const title = `Review: ${meta.branch || '—'} ← ${meta.base || 'develop'}`;

	const groupsHtml = doc.groups
		.map((g, i) => {
			const gTitle = escapeHtml(displayGroupTitle(g.title, g.kind));
			const blocks = doc.blocks.filter((b) => b.group === g.id);
			const paths = [...new Set(blocks.map((b) => b.file))];
			const files =
				paths.length > 0
					? `<ul class="files">${paths.map((p) => `<li><code>${escapeHtml(p)}</code></li>`).join('')}</ul>`
					: '';
			const blockLis = blocks
				.map((b) => {
					const loc = b.lines || (b.start && b.end ? `L${b.start}-${b.end}` : '');
					const why = b.why?.trim()
						? `<div class="why">${escapeHtml(b.why.trim())}</div>`
						: '';
					return `<li><code>${escapeHtml(b.file)}</code>${loc ? ` <span class="loc">${escapeHtml(loc)}</span>` : ''}: ${escapeHtml(b.what)}${why}</li>`;
				})
				.join('');
			return `<section class="group">
  <h3><span class="num">#${i + 1}</span> <span class="kind">${escapeHtml(kindLabel(g.kind))}</span> ${gTitle}</h3>
  ${g.intent?.trim() ? `<p class="intent">${escapeHtml(g.intent.trim())}</p>` : ''}
  ${files}
  ${blocks.length ? `<ul class="blocks">${blockLis}</ul>` : ''}
</section>`;
		})
		.join('\n');

	const findingsHtml = !doc.findings.length
		? '<p class="empty">Sin hallazgos.</p>'
		: doc.findings
				.map((f, i) => {
					const badge = f.blocking ? 'BLOQUEA' : severityLabel(f.severity).toUpperCase();
					const loc = f.file + (f.line ? `:${f.line}` : '');
					const cls = f.blocking ? 'blocking' : f.severity;
					return `<article class="finding ${escapeHtml(cls)}">
  <h3><span class="num">#${i + 1}</span> <span class="badge">${escapeHtml(badge)}</span> ${escapeHtml(findingKindLabel(f.kind))}</h3>
  <div class="meta"><code>${escapeHtml(loc)}</code> · ${escapeHtml(f.class)}</div>
  <p>${escapeHtml(f.what)}</p>
  ${f.fix?.trim() ? `<p class="fix"><strong>Sugerencia:</strong> ${escapeHtml(f.fix.trim())}</p>` : ''}
</article>`;
				})
				.join('\n');

	const notesHtml = doc.notes?.length
		? `<section><h2>Notas</h2><ul>${doc.notes.map((n) => `<li>${escapeHtml(n)}</li>`).join('')}</ul></section>`
		: '';

	const skippedHtml = doc.skipped?.length
		? `<section><h2>Omitidos</h2><ul>${doc.skipped.map((s) => `<li><code>${escapeHtml(s.file)}</code> (${escapeHtml(s.reason)})</li>`).join('')}</ul></section>`
		: '';

	return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>${escapeHtml(title)}</title>
<style>
  :root { color-scheme: light dark; }
  body { font: 14px/1.55 system-ui, sans-serif; max-width: 820px; margin: 32px auto; padding: 0 20px; color: #1a1a1a; background: #fff; }
  @media (prefers-color-scheme: dark) {
    body { color: #e8e8e8; background: #12141a; }
    code { background: #1e2430; }
    .group, .finding { border-color: #2a3140; }
  }
  h1 { font-size: 1.45rem; margin: 0 0 6px; }
  h2 { font-size: 1.15rem; margin: 28px 0 12px; border-bottom: 1px solid #ddd; padding-bottom: 6px; }
  h3 { font-size: 1rem; margin: 0 0 8px; }
  .sub { color: #666; font-size: 12.5px; margin-bottom: 20px; }
  code { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 0.9em; background: #f2f4f8; padding: 1px 4px; }
  .kind, .badge, .num { font-weight: 700; font-size: 11px; text-transform: uppercase; letter-spacing: 0.02em; }
  .kind, .badge { border: 1px solid #ccc; padding: 1px 6px; margin-right: 6px; }
  .finding.blocking .badge { border-color: #c44; color: #c44; }
  .group, .finding { border: 1px solid #e2e5ea; padding: 14px 16px; margin: 0 0 12px; }
  .intent, .why { color: #555; font-size: 13px; }
  .why { margin-top: 4px; font-style: italic; }
  .files, .blocks { margin: 8px 0 0; padding-left: 1.2em; }
  .loc { color: #888; font-size: 12px; }
  .fix { margin-top: 8px; }
  .empty { color: #888; }
  @media print {
    body { margin: 0; max-width: none; }
    .group, .finding { break-inside: avoid; }
  }
</style>
</head>
<body>
  <h1>${escapeHtml(title)}</h1>
  <p class="sub">${meta.repo ? escapeHtml(meta.repo) + ' · ' : ''}Guardado ${escapeHtml(report.savedAt)}</p>
  <section>
    <h2>Intención</h2>
    <p>${escapeHtml(doc.intent?.trim() || 'Sin intención.')}</p>
  </section>
  ${notesHtml}
  <section>
    <h2>Temas</h2>
    ${groupsHtml || '<p class="empty">Sin temas.</p>'}
  </section>
  <section>
    <h2>Hallazgos</h2>
    ${findingsHtml}
  </section>
  ${skippedHtml}
</body>
</html>`;
}

export function downloadReport(report: SavedReport, format: ExportFormat) {
	const base = slugBase(report);
	if (format === 'json') {
		triggerDownload(
			new Blob([JSON.stringify(report.document, null, 2)], { type: 'application/json;charset=utf-8' }),
			`${base}.json`
		);
		return;
	}
	if (format === 'md') {
		triggerDownload(new Blob([buildMarkdown(report)], { type: 'text/markdown;charset=utf-8' }), `${base}.md`);
		return;
	}
	const html = buildHtml(report);
	if (format === 'html') {
		triggerDownload(new Blob([html], { type: 'text/html;charset=utf-8' }), `${base}.html`);
		return;
	}
	// PDF: diálogo de impresión del navegador (Guardar como PDF).
	const w = window.open('', '_blank');
	if (!w) {
		triggerDownload(new Blob([html], { type: 'text/html;charset=utf-8' }), `${base}.html`);
		return;
	}
	w.document.open();
	w.document.write(html);
	w.document.close();
	w.focus();
	const runPrint = () => {
		try {
			w.print();
		} finally {
			w.close();
		}
	};
	if (w.document.readyState === 'complete') setTimeout(runPrint, 50);
	else w.addEventListener('load', () => setTimeout(runPrint, 50));
}
