export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set([]),
	mimeTypes: {},
	_: {
		client: {start:"_app/immutable/entry/start.DFSp9wIm.js",app:"_app/immutable/entry/app.DUpPambB.js",imports:["_app/immutable/entry/start.DFSp9wIm.js","_app/immutable/chunks/G1xn5Qsm.js","_app/immutable/chunks/Dur-vdUf.js","_app/immutable/entry/app.DUpPambB.js","_app/immutable/chunks/Dur-vdUf.js","_app/immutable/chunks/tYeNsyIK.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js'))
		],
		remotes: {
			'1g4ayag': __memo(() => import('./chunks/remote-1g4ayag.js'))
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/report/[id]",
				pattern: /^\/report\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
