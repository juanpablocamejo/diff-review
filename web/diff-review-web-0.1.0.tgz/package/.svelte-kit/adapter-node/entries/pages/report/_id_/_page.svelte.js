import { d as attr } from "../../../../chunks/index-server.js";
import { t as resolve } from "../../../../chunks/paths.js";
import { t as ThemeToggle } from "../../../../chunks/ThemeToggle.js";
import "../../../../chunks/git.remote.js";
import { themeIcons } from "seti-icons";
themeIcons({
	blue: "#4c8fd6",
	grey: "#7b8794",
	"grey-light": "#9aa3b2",
	green: "#6aa84f",
	orange: "#d08a3f",
	pink: "#c05a8a",
	purple: "#9b6fc4",
	red: "#c05a5a",
	white: "#8a93a6",
	yellow: "#c9a13b",
	ignore: "#7b8794"
});
//#endregion
//#region src/routes/report/[id]/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { params } = $$props;
		$$renderer.push(`<div class="page svelte-67dwv3"><header class="chrome svelte-67dwv3"><div class="chrome-left svelte-67dwv3"><a${attr("href", resolve("/"))} class="brand svelte-67dwv3"><span class="brand-dot svelte-67dwv3"></span> <span>diff-review</span></a> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="chrome-right svelte-67dwv3">`);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		ThemeToggle($$renderer, {});
		$$renderer.push(`<!----></div></header> `);
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<p class="hint svelte-67dwv3">Cargando…</p>`);
		$$renderer.push(`<!--]--></div>`);
	});
}
//#endregion
export { _page as default };
