import { a as ensure_array_like, c as stringify, d as attr, f as escape_html, i as derived, r as attr_class } from "../../chunks/index-server.js";
import { t as resolve } from "../../chunks/paths.js";
import { i as buildPrompt, n as OUTPUT_FILENAME, r as buildCommandText, t as ThemeToggle } from "../../chunks/ThemeToggle.js";
import "../../chunks/git.remote.js";
//#region src/lib/report/storage.ts
var LAST_META_KEY = "diff-review:last-meta";
function saveLastMeta(meta) {
	try {
		localStorage.setItem(LAST_META_KEY, JSON.stringify({
			source: meta.source === "url" ? "url" : "local",
			repo: meta.repo,
			branch: meta.branch,
			base: meta.base
		}));
	} catch {}
}
//#endregion
//#region src/routes/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let meta = {
			source: "local",
			repo: "",
			branch: "",
			base: "develop"
		};
		let promptText = "";
		let dragOver = false;
		let dropErrors = [];
		let reports = [];
		let reportMenuId = null;
		let branches = [];
		let loadingRepo = false;
		let pickingFolder = false;
		let hydrating = false;
		derived(() => buildCommandText(meta));
		function updateMeta(patch) {
			meta = {
				...meta,
				...patch
			};
			saveLastMeta(meta);
			promptText = buildPrompt(meta);
		}
		function fmtWhen(iso) {
			const d = new Date(iso);
			if (Number.isNaN(d.getTime())) return iso;
			return d.toLocaleString("es-AR", {
				day: "2-digit",
				month: "2-digit",
				hour: "2-digit",
				minute: "2-digit"
			});
		}
		$$renderer.push(`<div class="page svelte-1uha8ag"><header class="topbar svelte-1uha8ag"><a${attr("href", resolve("/"))} class="brand svelte-1uha8ag"><span class="brand-dot svelte-1uha8ag"></span> <span class="title-block svelte-1uha8ag"><span class="svelte-1uha8ag">diff-review</span> <small class="svelte-1uha8ag">generá un prompt, corré tu agente, soltá el resultado</small></span></a> `);
		ThemeToggle($$renderer, {});
		$$renderer.push(`<!----></header> <div class="workspace svelte-1uha8ag"><section class="setup svelte-1uha8ag"><h2 class="svelte-1uha8ag">1. Contexto</h2> <div class="mode-toggle source-toggle svelte-1uha8ag"><button type="button"${attr_class("svelte-1uha8ag", void 0, { "on": meta.source === "local" })}>Carpeta local</button> <button type="button"${attr_class("svelte-1uha8ag", void 0, { "on": meta.source === "url" })}>URL remota</button></div> <p class="hint-text svelte-1uha8ag">`);
		if (meta.source === "url") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`URL del remote (https / SSH). Al cargar se listan branches con <code class="svelte-1uha8ag">ls-remote</code>; al soltar el
					JSON se hace un clone shallow temporal para armar el diff. Requiere que el branch esté en el remote.`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`Carpeta local del repo. Podés pegar la ruta o elegirla con el diálogo del sistema. Git corre ahí
					mismo (sirve para branches no pusheados).`);
		}
		$$renderer.push(`<!--]--></p> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (branches.length) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<p class="ok-line svelte-1uha8ag">${escape_html(branches.length)} branch${escape_html(branches.length === 1 ? "" : "es")} encontrado${escape_html(branches.length === 1 ? "" : "s")}.</p>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="row svelte-1uha8ag"><label class="field repo-field svelte-1uha8ag"><span class="svelte-1uha8ag">${escape_html(meta.source === "url" ? "URL del repo" : "Repo")}</span> <div class="repo-row svelte-1uha8ag"><input type="text"${attr("placeholder", meta.source === "url" ? "https://github.com/org/repo.git" : "C:\\path\\to\\repo")}${attr("value", meta.repo)} class="svelte-1uha8ag"/> `);
		if (meta.source === "local") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button type="button"${attr("disabled", loadingRepo, true)} class="svelte-1uha8ag">${escape_html("Elegir…")}</button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <button type="button"${attr("disabled", pickingFolder, true)} class="svelte-1uha8ag">${escape_html("Cargar")}</button></div></label> <label class="field svelte-1uha8ag"><span class="svelte-1uha8ag">Branch a revisar</span> `);
		if (branches.length) {
			$$renderer.push("<!--[0-->");
			$$renderer.select({
				value: meta.branch,
				onchange: (e) => updateMeta({ branch: e.currentTarget.value }),
				class: ""
			}, ($$renderer) => {
				$$renderer.push(`<!--[-->`);
				const each_array = ensure_array_like(branches);
				for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
					let b = each_array[$$index];
					$$renderer.option({ value: b }, ($$renderer) => {
						$$renderer.push(`${escape_html(b)}`);
					});
				}
				$$renderer.push(`<!--]-->`);
			}, "svelte-1uha8ag");
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<input type="text" placeholder="feature/PCM-14839"${attr("value", meta.branch)} class="svelte-1uha8ag"/>`);
		}
		$$renderer.push(`<!--]--></label> <label class="field svelte-1uha8ag"><span class="svelte-1uha8ag">Base</span> `);
		if (branches.length) {
			$$renderer.push("<!--[0-->");
			$$renderer.select({
				value: meta.base,
				onchange: (e) => updateMeta({ base: e.currentTarget.value }),
				class: ""
			}, ($$renderer) => {
				$$renderer.push(`<!--[-->`);
				const each_array_1 = ensure_array_like(branches);
				for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
					let b = each_array_1[$$index_1];
					$$renderer.option({ value: b }, ($$renderer) => {
						$$renderer.push(`${escape_html(b)}`);
					});
				}
				$$renderer.push(`<!--]-->`);
			}, "svelte-1uha8ag");
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<input type="text" placeholder="develop"${attr("value", meta.base)} class="svelte-1uha8ag"/>`);
		}
		$$renderer.push(`<!--]--></label></div> <div class="section-head svelte-1uha8ag"><h2 class="svelte-1uha8ag">2. Prompt</h2> <button type="button" class="link svelte-1uha8ag">↺ Regenerar desde el contexto</button></div> <div class="mode-toggle svelte-1uha8ag"><button type="button"${attr_class("svelte-1uha8ag", void 0, { "on": true })}>Prompt completo</button> <button type="button"${attr_class("svelte-1uha8ag", void 0, { "on": false })}>Comando (skill)</button></div> `);
		{
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<p class="hint-text svelte-1uha8ag">Copiá esto en Claude, Cursor, Copilot o el agente que uses. El schema de salida va incluido.</p> <textarea class="svelte-1uha8ag">`);
			const $$body = escape_html(promptText);
			if ($$body) $$renderer.push(`${$$body}`);
			$$renderer.push(`</textarea> <div class="actions svelte-1uha8ag"><button type="button" class="primary svelte-1uha8ag">${escape_html("Copiar prompt")}</button> <button type="button" class="ghost svelte-1uha8ag">Ver ejemplo</button></div>`);
		}
		$$renderer.push(`<!--]--> <h2 class="result-head svelte-1uha8ag">3. Resultado</h2> <p class="hint-text svelte-1uha8ag">Soltá acá el <code class="svelte-1uha8ag">${escape_html(OUTPUT_FILENAME)}</code> que generó el agente. El diff lo completa git.</p> <div${attr_class("dropzone svelte-1uha8ag", void 0, {
			"drag": dragOver,
			"busy": hydrating
		})} role="presentation"><p class="svelte-1uha8ag">${escape_html("Arrastrá el archivo .json acá")}</p> <button type="button"${attr("disabled", hydrating, true)} class="svelte-1uha8ag">Elegir archivo</button> <input type="file" accept="application/json,.json" class="visually-hidden svelte-1uha8ag"/></div> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (dropErrors.length) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="drop-errors svelte-1uha8ag"><strong class="svelte-1uha8ag">No se pudo abrir el reporte:</strong> <ul class="svelte-1uha8ag"><!--[-->`);
			const each_array_3 = ensure_array_like(dropErrors);
			for (let $$index_3 = 0, $$length = each_array_3.length; $$index_3 < $$length; $$index_3++) {
				let err = each_array_3[$$index_3];
				$$renderer.push(`<li>${escape_html(err)}</li>`);
			}
			$$renderer.push(`<!--]--></ul></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></section> <aside class="reports-col svelte-1uha8ag"><h2 class="svelte-1uha8ag">Reportes anteriores</h2> `);
		if (reports.length) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<ul class="report-list svelte-1uha8ag"><!--[-->`);
			const each_array_4 = ensure_array_like(reports);
			for (let $$index_4 = 0, $$length = each_array_4.length; $$index_4 < $$length; $$index_4++) {
				let item = each_array_4[$$index_4];
				$$renderer.push(`<li class="report-item svelte-1uha8ag"><a class="report-card svelte-1uha8ag"${attr("href", resolve(`/report/${item.id}`))}><span class="report-top svelte-1uha8ag"><strong class="svelte-1uha8ag">${escape_html(item.branch || "—")}</strong> <span class="when svelte-1uha8ag">${escape_html(fmtWhen(item.savedAt))}</span></span> <span class="report-meta svelte-1uha8ag"><span>vs ${escape_html(item.base || "develop")}</span> <span class="pill svelte-1uha8ag">${escape_html(item.groupCount)} tema${escape_html(item.groupCount === 1 ? "" : "s")}</span> `);
				if (item.blockerCount) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="pill bad svelte-1uha8ag">${escape_html(item.blockerCount)} blocker${escape_html(item.blockerCount === 1 ? "" : "s")}</span>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (item.qualityCount) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="pill svelte-1uha8ag">${escape_html(item.qualityCount)} calidad</span>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></span> `);
				if (item.intent) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<p class="report-intent svelte-1uha8ag">${escape_html(item.intent)}</p>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></a> <div class="report-actions svelte-1uha8ag"><button type="button" class="kebab svelte-1uha8ag" title="Más acciones"${attr("aria-label", `Más acciones para ${stringify(item.branch || "reporte")}`)}${attr("aria-expanded", reportMenuId === item.id)} aria-haspopup="menu"><svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><circle cx="8" cy="3.5" r="1.25" fill="currentColor"></circle><circle cx="8" cy="8" r="1.25" fill="currentColor"></circle><circle cx="8" cy="12.5" r="1.25" fill="currentColor"></circle></svg></button> `);
				if (reportMenuId === item.id) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="report-menu svelte-1uha8ag" role="menu" tabindex="-1"><button type="button" class="menu-item danger svelte-1uha8ag" role="menuitem">Eliminar…</button></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div></li>`);
			}
			$$renderer.push(`<!--]--></ul>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<p class="hint-text svelte-1uha8ag">Todavía no hay reportes. Generá un prompt, corré tu agente y soltá el JSON.</p>`);
		}
		$$renderer.push(`<!--]--></aside></div></div>`);
	});
}
//#endregion
export { _page as default };
