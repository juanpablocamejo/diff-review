import { f as escape_html, o as head } from "../../chunks/index-server.js";
import "../../chunks/theme.js";
//#region src/routes/+layout.svelte
function _layout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { children } = $$props;
		function failed($$renderer, error, reset) {
			$$renderer.push(`<div class="boot svelte-12qhfyh"><p>${escape_html(error instanceof Error ? error.message : String(error))}</p> <button type="button" class="svelte-12qhfyh">Reintentar</button></div>`);
		}
		head("12qhfyh", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>diff-review</title>`);
			});
		});
		$$renderer.boundary({ failed }, ($$renderer) => {
			$$renderer.push(`<!--[!-->`);
			$$renderer.push(`<div class="boot svelte-12qhfyh">Cargando…</div>`);
			$$renderer.push(`<!--]-->`);
		});
	});
}
//#endregion
export { _layout as default };
