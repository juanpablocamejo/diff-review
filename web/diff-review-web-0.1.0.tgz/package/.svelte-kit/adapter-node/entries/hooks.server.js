//#region src/hooks.server.ts
/** Herramienta local: conviene ver el error real (git, devalue, etc.) y no el 500 genérico. */
var handleError = ({ error, message }) => {
	console.error("[diff-review]", error);
	if (error instanceof Error && error.message.trim()) return { message: error.message };
	if (error && typeof error === "object" && "message" in error) {
		const detail = String(error.message || "").trim();
		if (detail) return { message: detail };
	}
	return { message: message || "Error interno" };
};
//#endregion
export { handleError };
