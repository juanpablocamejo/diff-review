import { t as git_remote_exports } from "./git.remote.js";
//#region \0sveltekit-remote:1g4ayag
var _sveltekit_remote_1g4ayag_default = git_remote_exports;
//#endregion
export { _sveltekit_remote_1g4ayag_default as default };
