import { d as attr, f as escape_html } from "./index-server.js";
import "./theme.js";
import "./client.js";
import "highlight.js/lib/common";
//#region src/lib/report/prompts.ts
var OUTPUT_SCHEMA_BLOCK = `{
  "intent": "2-4 oraciones: qué problema resuelve el branch y cómo. Sin listar archivos.",
  "groups": [
    { "id": "g1", "kind": "feat|fix|refactor|perf|test|chore|docs|infra", "title": "scope: título en imperativo, máx 72 caracteres (sin repetir el kind)", "intent": "1-2 oraciones sobre este tema" }
  ],
  "blocks": [
    {
      "id": "b1", "group": "g1", "file": "path/relativo/al/archivo.ext", "lines": "L40-58",
      "side": "new|old", "start": 40, "end": 58, "op": "add|mod|del|rename",
      "what": "qué cambia, máx 120 caracteres", "why": "por qué, máx 120 caracteres",
      "source": "code|commit|pr|issue|inferred"
    }
  ],
  "findings": [
    {
      "id": "f1", "class": "risk|quality", "severity": "high|med|low|nit",
      "blocking": false,
      "kind": "bug|race|auth|security|api-break|missing-test|perf|maintainability|docs|other",
      "file": "path/relativo/al/archivo.ext", "line": 87, "block": "b1",
      "what": "qué está mal, máx 120 caracteres", "fix": "cómo arreglarlo, máx 120 caracteres"
    }
  ],
  "skipped": [
    { "file": "path/relativo", "reason": "generated|lockfile|format|vendored|binary|trivial|ignored" }
  ],
  "notes": ["notas breves sobre limitaciones de la review, si aplica"]
}`;
var RULES = `- NO reportar: código preexistente fuera del diff, ruido de linter/formatter, preferencias de naming/estilo sin consecuencia real, comportamiento intencional del branch, reglas de lint silenciadas, "falta doc/cobertura" sin un escenario concreto roto.
- Los hallazgos de calidad tienen que nombrar un costo concreto, no una sensación vaga.
- "blocking": true SOLO si el branch no debería mergearse tal como está.
- Un "block" por tramo de cambio con sentido propio (no uno por línea). Cada finding puntual usa el "block" de ese tramo; si es transversal, "block" queda vacío.`;
/** Nombre del archivo donde el agente debe escribir el JSON (intent/groups/blocks/findings; el diff lo arma la UI con git). */
var OUTPUT_FILENAME = "diff-review-output.json";
function buildPrompt(meta) {
	const repo = meta.repo.trim() || (meta.source === "url" ? "<url del repo>" : "<ruta absoluta del repo>");
	const branch = meta.branch.trim() || "<branch a revisar>";
	const base = meta.base.trim() || "develop";
	return `Actuá como revisor de código senior, exigente pero justo.

Repo: ${repo}
Branch a revisar: ${branch}
Base (merge-base): ${base}

${meta.source === "url" ? `El repo está en remoto. Si no lo tenés local, clonalo (o usá el acceso que tengas) y corré \`git diff ${base}...${branch}\` (o el diff que corresponda); leé los archivos que necesites para entender tipos, callers y tests. No modifiques nada.` : `Tenés acceso al repo: corré \`git diff ${base}...${branch}\` (o el diff que corresponda) y leé los archivos que necesites para entender tipos, callers y tests. No modifiques nada.`}

Reglas:
${RULES}

Escribí el resultado en un archivo llamado \`${OUTPUT_FILENAME}\` en la raíz del repo. El archivo debe tener UN SOLO objeto JSON, sin texto antes ni después, sin bloques \`\`\`, con esta forma exacta:

${OUTPUT_SCHEMA_BLOCK}

NO incluyas diffs ni un array "files": la herramienta los calcula con git al abrir el reporte. Tampoco inventes hunks ni copies el parche al JSON.

Cuando termines, avisame que \`${OUTPUT_FILENAME}\` quedó escrito.`;
}
function buildCommandText(meta) {
	const parts = [];
	if (meta.repo.trim()) parts.push(`repo=${meta.repo.trim()}`);
	if (meta.branch.trim()) parts.push(`branch=${meta.branch.trim()}`);
	parts.push(`base=${(meta.base || "develop").trim()}`);
	return `/diff-review ${parts.join(" ")}`.trim();
}
//#endregion
//#region src/lib/ThemeToggle.svelte
function ThemeToggle($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		$$renderer.push(`<button type="button" class="theme-toggle svelte-lu0t34"${attr("title", "Modo claro")}>${escape_html("◐")}</button>`);
	});
}
//#endregion
export { buildPrompt as i, OUTPUT_FILENAME as n, buildCommandText as r, ThemeToggle as t };
