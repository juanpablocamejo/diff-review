import { X as __exportAll } from "./index-server.js";
import "./shared.js";
import { a as command, n as query } from "./remote.js";
import "./paths.js";
import { error } from "@sveltejs/kit";
import { init_remote_functions } from "@sveltejs/kit/internal";
import "@sveltejs/kit/internal/server";
import { existsSync, mkdirSync, readFileSync, rmSync } from "node:fs";
import { join, resolve } from "node:path";
import { execFileSync } from "node:child_process";
import { platform, tmpdir } from "node:os";
import { createHash } from "node:crypto";
//#region ../lib/config.mjs
var DEFAULT_IGNORE = [
	"**/package-lock.json",
	"**/pnpm-lock.yaml",
	"**/yarn.lock",
	"**/bun.lock",
	"**/bun.lockb",
	"**/*.g.cs",
	"**/*Snapshot.cs",
	"**/*.Designer.cs",
	"**/node_modules/**",
	"**/.svelte-kit/**",
	"**/dist/**",
	"**/build/**",
	"**/*.min.js",
	"**/*.min.css",
	"**/CODE_REVIEW_CORRECTNESS_FINDINGS.md"
];
var STORE_DIFF_MAX = 4e5;
var GUIDELINE_FILES = [
	"REVIEW.md",
	"CLAUDE.md",
	"AGENTS.md"
];
function unquote(s) {
	const t = String(s || "").trim();
	if (t.startsWith("\"") && t.endsWith("\"") || t.startsWith("'") && t.endsWith("'")) return t.slice(1, -1);
	return t;
}
/** Minimal YAML: `key: value` and `key:\n  - item`. */
function parseSimpleYaml(text) {
	const result = {};
	let key = null;
	for (const raw of String(text || "").split(/\r?\n/)) {
		if (!raw.trim() || raw.trim().startsWith("#")) continue;
		const list = raw.match(/^\s+-\s+(.*)$/);
		if (list && key) {
			if (!Array.isArray(result[key])) result[key] = [];
			result[key].push(unquote(list[1]));
			continue;
		}
		const kv = raw.match(/^([A-Za-z][\w]*)\s*:\s*(.*)$/);
		if (!kv) continue;
		key = kv[1];
		const v = kv[2].trim();
		result[key] = v === "" ? [] : unquote(v);
	}
	return result;
}
function globToRegExp(glob) {
	let g = String(glob || "").replace(/\\/g, "/");
	if (!g.includes("/")) g = `**/${g}`;
	let s = "";
	for (let i = 0; i < g.length; i++) {
		const c = g[i];
		if (c === "*" && g[i + 1] === "*") if (g[i + 2] === "/") {
			s += "(?:.*/)?";
			i += 2;
		} else {
			s += ".*";
			i += 1;
		}
		else if (c === "*") s += "[^/]*";
		else if (c === "?") s += "[^/]";
		else if ("+()[]{}|.^$".includes(c)) s += `\\${c}`;
		else s += c;
	}
	return new RegExp(`^${s}$`, "i");
}
function globMatch(filePath, pattern) {
	const norm = String(filePath || "").replace(/\\/g, "/");
	return globToRegExp(pattern).test(norm);
}
function isIgnored(filePath, patterns) {
	return (patterns || []).some((p) => globMatch(filePath, p));
}
function isTestPath(filePath) {
	const p = String(filePath || "").replace(/\\/g, "/");
	return /(^|\/)(__tests__|tests?|spec)s?(\/|$)/i.test(p) || /\.(test|spec)\.[^.]+$/i.test(p);
}
function readIfExists(path) {
	try {
		return existsSync(path) ? readFileSync(path, "utf8") : null;
	} catch {
		return null;
	}
}
function loadReviewConfig(repo) {
	const jsonText = readIfExists(join(repo, ".diff-review.json"));
	const yamlText = readIfExists(join(repo, ".diff-review.yml")) || readIfExists(join(repo, ".diff-review.yaml"));
	let extra = {};
	if (jsonText) try {
		extra = JSON.parse(jsonText);
	} catch {
		extra = {};
	}
	else if (yamlText) extra = parseSimpleYaml(yamlText);
	const extraIgnore = Array.isArray(extra.ignore) ? extra.ignore.map(String) : [];
	const rulesFile = extra.rulesFile ? String(extra.rulesFile) : "REVIEW.md";
	const rules = readIfExists(join(repo, rulesFile)) || "";
	const model = extra.model && extra.model !== "default" ? String(extra.model) : null;
	return {
		ignore: [...DEFAULT_IGNORE, ...extraIgnore],
		model,
		rulesFile,
		rules: rules.trim()
	};
}
/** CLAUDE.md / REVIEW.md / AGENTS.md from repo root and immediate parent dirs of touched files. */
function collectGuidelines(repo, filePaths, { rulesFile = "REVIEW.md", maxChars = 8e3, maxTotalChars = 12e3, maxDepth = 1, skipNames = [] } = {}) {
	const skip = new Set(skipNames);
	const names = [.../* @__PURE__ */ new Set([rulesFile, ...GUIDELINE_FILES])].filter((name) => !skip.has(name));
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	const addRel = (rel) => {
		const norm = String(rel || "").replace(/\\/g, "/").replace(/^\/+/, "");
		if (!norm || seen.has(norm)) return;
		const text = readIfExists(join(repo, ...norm.split("/")));
		if (!text || !text.trim()) return;
		seen.add(norm);
		out.push({
			path: norm,
			text: text.trim()
		});
	};
	for (const name of names) addRel(name);
	const depth = Math.max(1, Number(maxDepth) || 1);
	for (const filePath of filePaths || []) {
		const parts = String(filePath || "").replace(/\\/g, "/").split("/").filter(Boolean);
		const minLen = Math.max(1, parts.length - depth);
		for (let len = parts.length - 1; len >= minLen; len--) {
			const dir = parts.slice(0, len).join("/");
			for (const name of names) addRel(`${dir}/${name}`);
		}
	}
	let total = 0;
	const capped = [];
	for (const item of out) {
		if (total >= maxTotalChars) break;
		const room = maxTotalChars - total;
		const slice = item.text.slice(0, Math.min(maxChars, room));
		if (!slice) continue;
		capped.push({
			path: item.path,
			text: slice
		});
		total += slice.length;
	}
	return capped;
}
function capDiff(diff, max = STORE_DIFF_MAX) {
	const text = String(diff || "");
	if (text.length <= max) return {
		diff: text,
		diffChars: text.length,
		truncated: false
	};
	return {
		diff: `${text.slice(0, max)}\n\n… [diff recortado: se guardan ${max} de ${text.length} caracteres]`,
		diffChars: text.length,
		truncated: true
	};
}
//#endregion
//#region ../lib/git.mjs
function assertGitRepo(repo) {
	const raw = String(repo || "").trim();
	if (!raw) throw new Error("Indicá la ruta absoluta de un repositorio git.");
	if (!/[\\/]/.test(raw) && !/^[A-Za-z]:/.test(raw)) throw new Error(`"${raw}" no es una ruta. Pegá la ruta absoluta del repo (ej. C:\\tienda-argenta\\tienda-argenta-2).`);
	const resolved = resolve(raw);
	if (!resolved || resolved === ".") throw new Error("Indicá la ruta absoluta de un repositorio git.");
	if (!existsSync(resolved)) throw new Error(`No existe la carpeta: ${resolved}`);
	if (!existsSync(join(resolved, ".git"))) throw new Error(`No es un repositorio git (falta .git): ${resolved}`);
	return resolved;
}
function git(repo, args, { maxBuffer = 64 * 1024 * 1024 } = {}) {
	return execFileSync("git", args, {
		cwd: repo,
		encoding: "utf8",
		maxBuffer,
		windowsHide: true
	});
}
function commitLog(repo, mergeBase, branch, limit = 25) {
	try {
		return git(repo, [
			"log",
			"--oneline",
			"--no-merges",
			"-n",
			String(limit),
			`${mergeBase}..${branch}`
		]).trim().split("\n").filter(Boolean);
	} catch {
		return [];
	}
}
var FILE_LINE_CACHE = /* @__PURE__ */ new Map();
var FILE_LINE_CACHE_MAX = 48;
function rememberFileLines(key, lines) {
	if (FILE_LINE_CACHE.has(key)) FILE_LINE_CACHE.delete(key);
	FILE_LINE_CACHE.set(key, lines);
	while (FILE_LINE_CACHE.size > FILE_LINE_CACHE_MAX) {
		const oldest = FILE_LINE_CACHE.keys().next().value;
		FILE_LINE_CACHE.delete(oldest);
	}
}
function showFileLines(repo, rev, path) {
	const resolved = assertGitRepo(repo);
	const safeRev = String(rev || "").trim();
	const safePath = String(path || "").replace(/\\/g, "/").trim();
	if (!safeRev || !/^[A-Za-z0-9._/\-]+$/.test(safeRev)) throw new Error("Rev inválido.");
	if (!safePath || safePath.startsWith("/") || safePath.includes("..") || safePath.includes("\0")) throw new Error("Ruta inválida.");
	const key = `${resolved}\0${safeRev}\0${safePath}`;
	if (FILE_LINE_CACHE.has(key)) return FILE_LINE_CACHE.get(key);
	let text;
	try {
		text = git(resolved, ["show", `${safeRev}:${safePath}`]);
	} catch {
		rememberFileLines(key, null);
		return null;
	}
	if (text.includes("\0")) {
		rememberFileLines(key, null);
		return null;
	}
	const raw = text.replace(/\r\n/g, "\n");
	const lines = raw.endsWith("\n") ? raw.slice(0, -1).split("\n") : raw.split("\n");
	rememberFileLines(key, lines);
	return lines;
}
function listBranches(repo) {
	const names = git(repo, [
		"for-each-ref",
		"--sort=-committerdate",
		"--format=%(refname:short)",
		"refs/heads",
		"refs/remotes"
	]).split("\n").map((s) => s.trim()).filter(Boolean).map((name) => name.replace(/^origin\//, "")).filter((name) => name !== "HEAD" && !name.endsWith("/HEAD"));
	const unique = [...new Set(names)];
	const current = git(repo, [
		"rev-parse",
		"--abbrev-ref",
		"HEAD"
	]).trim();
	const bases = unique.filter((n) => n === "develop" || n === "main" || n === "master");
	return {
		branches: unique,
		current,
		defaultBase: bases.includes("develop") ? "develop" : bases.includes("main") ? "main" : bases[0] || "develop"
	};
}
//#endregion
//#region ../lib/extract.mjs
function extractBranchDiff({ repo, branch, base = "develop" }) {
	if (!branch) throw new Error("Falta el branch a revisar.");
	const config = loadReviewConfig(repo);
	const mergeBase = git(repo, [
		"merge-base",
		base,
		branch
	]).trim();
	const branchSha = git(repo, ["rev-parse", branch]).trim();
	const baseSha = git(repo, ["rev-parse", base]).trim();
	const nameStatus = git(repo, [
		"diff",
		mergeBase,
		branch,
		"--name-status"
	]).trim().split("\n").filter(Boolean).map((line) => {
		const [status, ...rest] = line.split("	");
		const path = rest[rest.length - 1];
		const oldPath = rest.length > 1 ? rest[0] : null;
		let changeType = "modified";
		if (status.startsWith("A")) changeType = "added";
		else if (status.startsWith("D")) changeType = "deleted";
		else if (status.startsWith("R")) changeType = "renamed";
		return {
			path,
			oldPath,
			changeType
		};
	});
	const ignored = [];
	const included = [];
	for (const f of nameStatus) if (isIgnored(f.path, config.ignore)) ignored.push(f.path);
	else included.push(f);
	const files = included.map((f) => {
		let raw = "";
		try {
			raw = git(repo, [
				"diff",
				mergeBase,
				branch,
				"--",
				f.path
			]);
			const idx = raw.indexOf("\n@@");
			if (idx !== -1) raw = raw.slice(idx + 1);
		} catch {
			raw = "";
		}
		const capped = capDiff(raw);
		return {
			path: f.path,
			oldPath: f.oldPath || void 0,
			changeType: f.changeType,
			diff: capped.diff,
			diffChars: capped.diffChars,
			truncated: capped.truncated,
			modelChars: capped.diff.length,
			group: ""
		};
	});
	const shortstat = git(repo, [
		"diff",
		mergeBase,
		branch,
		"--shortstat"
	]).trim();
	const insMatch = shortstat.match(/(\d+) insertion/);
	const delMatch = shortstat.match(/(\d+) deletion/);
	return {
		version: 2,
		repo,
		branch,
		baseBranch: base,
		mergeBase,
		branchSha,
		baseSha,
		generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		intent: "",
		stats: {
			filesChanged: files.length,
			filesIgnored: ignored.length,
			filesTruncated: files.filter((f) => f.truncated).length,
			insertions: insMatch ? Number(insMatch[1]) : 0,
			deletions: delMatch ? Number(delMatch[1]) : 0
		},
		context: {
			commits: commitLog(repo, mergeBase, branch),
			rules: config.rules,
			rulesFile: config.rulesFile,
			ignored: ignored.slice(0, 40),
			testsTouched: files.filter((f) => isTestPath(f.path)).map((f) => f.path),
			testsMissing: files.filter((f) => !isTestPath(f.path)).length,
			guidelines: collectGuidelines(repo, files.map((f) => f.path), {
				rulesFile: config.rulesFile,
				skipNames: config.rules.trim() ? [config.rulesFile] : [],
				maxDepth: 1,
				maxChars: 8e3,
				maxTotalChars: 12e3
			})
		},
		files,
		groups: [],
		blocks: [],
		findings: [],
		skipped: []
	};
}
//#endregion
//#region ../lib/pick-folder.mjs
/**
* Abre el diálogo nativo del OS para elegir una carpeta.
* @returns {string|null} Ruta absoluta, o null si el usuario canceló.
*/
function pickFolder() {
	const os = platform();
	if (os === "win32") return pickWindows();
	if (os === "darwin") return pickMac();
	return pickLinux();
}
function pickWindows() {
	const script = [
		"Add-Type -AssemblyName System.Windows.Forms",
		"$d = New-Object System.Windows.Forms.FolderBrowserDialog",
		"$d.Description = 'Elegí el repositorio git'",
		"$d.ShowNewFolderButton = $false",
		"if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $d.SelectedPath }"
	].join("; ");
	try {
		const out = execFileSync("powershell.exe", [
			"-NoProfile",
			"-STA",
			"-ExecutionPolicy",
			"Bypass",
			"-Command",
			script
		], {
			encoding: "utf8",
			windowsHide: false,
			timeout: 600 * 1e3
		});
		return String(out || "").trim() || null;
	} catch (err) {
		const msg = err instanceof Error ? err.message : String(err);
		if (/canceled|cancelled|abort/i.test(msg)) return null;
		throw new Error("No se pudo abrir el diálogo de carpetas: " + msg);
	}
}
function pickMac() {
	try {
		const out = execFileSync("osascript", ["-e", "POSIX path of (choose folder with prompt \"Elegí el repositorio git\")"], {
			encoding: "utf8",
			timeout: 600 * 1e3
		});
		return String(out || "").trim().replace(/\/$/, "");
	} catch (err) {
		if (err.status === 1 || /User canceled|-128/i.test(String(err))) return null;
		throw new Error("No se pudo abrir el diálogo de carpetas: " + (err instanceof Error ? err.message : String(err)));
	}
}
function pickLinux() {
	try {
		const out = execFileSync("zenity", [
			"--file-selection",
			"--directory",
			"--title=Elegí el repositorio git"
		], {
			encoding: "utf8",
			timeout: 600 * 1e3
		});
		return String(out || "").trim() || null;
	} catch (zenityErr) {
		if (zenityErr.status === 1) return null;
		try {
			const out = execFileSync("kdialog", [
				"--getexistingdirectory",
				".",
				"Elegí el repositorio git"
			], {
				encoding: "utf8",
				timeout: 600 * 1e3
			});
			return String(out || "").trim() || null;
		} catch (kErr) {
			if (kErr.status === 1) return null;
			throw new Error("No hay diálogo de carpetas disponible. Instalá zenity o kdialog, o pegá la ruta a mano.");
		}
	}
}
//#endregion
//#region ../lib/remote-repo.mjs
var CACHE_ROOT = join(tmpdir(), "diff-review-clones");
var MAX_DEEPEN_ROUNDS = 8;
var DEEPEN_BY = "50";
function looksLikeGitUrl(value) {
	const v = String(value || "").trim();
	if (!v) return false;
	if (/^(https?:\/\/|git@|ssh:\/\/)/i.test(v)) return true;
	if (/\.git$/i.test(v) && !/^[A-Za-z]:/.test(v) && !v.startsWith("/") && !v.startsWith("\\")) return true;
	return false;
}
function normalizeGitUrl(url) {
	const raw = String(url || "").trim();
	if (!raw) throw new Error("Indicá la URL del repositorio.");
	if (!looksLikeGitUrl(raw)) throw new Error(`"${raw}" no parece una URL git. Usá https://…, git@… o ssh://…`);
	if (/^(file:|javascript:|data:)/i.test(raw)) throw new Error("Esquema de URL no permitido.");
	return raw.replace(/\/$/, "");
}
function cacheDirFor(url) {
	return join(CACHE_ROOT, createHash("sha1").update(url).digest("hex").slice(0, 16));
}
function runGit(args, { cwd, timeout = 300 * 1e3 } = {}) {
	return execFileSync("git", args, {
		cwd,
		encoding: "utf8",
		windowsHide: true,
		timeout,
		maxBuffer: 64 * 1024 * 1024
	});
}
/** Lista heads del remote sin clonar. */
function listRemoteBranches(url) {
	const remote = normalizeGitUrl(url);
	let raw;
	try {
		raw = runGit([
			"ls-remote",
			"--heads",
			remote
		]);
	} catch (err) {
		const stderr = String(
			/** @type {{ stderr?: string }} */
			err.stderr || err.message || err
		);
		throw new Error("No se pudo listar branches del remote: " + stderr.split("\n").find(Boolean));
	}
	const branches = [...new Set(raw.split("\n").map((line) => line.trim()).filter(Boolean).map((line) => {
		return (line.split("	")[1] || "").replace(/^refs\/heads\//, "");
	}).filter(Boolean))].sort((a, b) => a.localeCompare(b));
	if (!branches.length) throw new Error("El remote no expone branches (refs/heads).");
	return {
		branches,
		current: "",
		defaultBase: branches.includes("develop") ? "develop" : branches.includes("main") ? "main" : branches.includes("master") ? "master" : branches[0]
	};
}
function fetchRef(repo, ref) {
	const name = String(ref || "").trim();
	if (!name) return;
	try {
		runGit([
			"rev-parse",
			"--verify",
			name
		], { cwd: repo });
		return;
	} catch {}
	runGit([
		"fetch",
		"--depth",
		DEEPEN_BY,
		"origin",
		`refs/heads/${name}:refs/heads/${name}`
	], { cwd: repo });
}
function deepenUntilMergeBase(repo, base, branch) {
	for (let i = 0; i < MAX_DEEPEN_ROUNDS; i++) try {
		git(repo, [
			"merge-base",
			base,
			branch
		]);
		return;
	} catch {
		runGit([
			"fetch",
			"--deepen",
			DEEPEN_BY,
			"origin",
			`refs/heads/${base}:refs/heads/${base}`,
			`refs/heads/${branch}:refs/heads/${branch}`
		], { cwd: repo });
	}
	throw new Error(`No se encontró merge-base entre "${base}" y "${branch}" (historial shallow insuficiente). Probá con más historia o usá una carpeta local.`);
}
/**
* Asegura un worktree local (cache en tmp) con branch y base disponibles para diff.
* @returns {string} ruta absoluta del clone
*/
function ensureRemoteWorktree(url, branch, base = "develop") {
	const remote = normalizeGitUrl(url);
	const b = String(branch || "").trim();
	const baseRef = String(base || "develop").trim() || "develop";
	if (!b) throw new Error("Falta el branch a revisar.");
	mkdirSync(CACHE_ROOT, { recursive: true });
	const dir = cacheDirFor(remote);
	if (!existsSync(join(dir, ".git"))) {
		if (existsSync(dir)) rmSync(dir, {
			recursive: true,
			force: true
		});
		try {
			runGit([
				"clone",
				"--filter=blob:none",
				"--depth",
				DEEPEN_BY,
				"--branch",
				b,
				remote,
				dir
			], { timeout: 600 * 1e3 });
		} catch (err) {
			if (existsSync(dir)) rmSync(dir, {
				recursive: true,
				force: true
			});
			const stderr = String(
				/** @type {{ stderr?: string }} */
				err.stderr || err.message || err
			);
			throw new Error("No se pudo clonar el repo: " + stderr.split("\n").find(Boolean));
		}
	} else {
		try {
			runGit([
				"remote",
				"set-url",
				"origin",
				remote
			], { cwd: dir });
		} catch {}
		fetchRef(dir, b);
		try {
			runGit([
				"checkout",
				"--force",
				b
			], { cwd: dir });
		} catch {}
	}
	if (baseRef !== b) fetchRef(dir, baseRef);
	deepenUntilMergeBase(dir, baseRef, b);
	return dir;
}
//#endregion
//#region ../lib/validate.mjs
var GROUP_KINDS = [
	"feat",
	"fix",
	"refactor",
	"perf",
	"test",
	"chore",
	"docs",
	"infra"
];
var BLOCK_OPS = [
	"add",
	"mod",
	"del",
	"rename"
];
var WHY_SOURCES = [
	"code",
	"commit",
	"pr",
	"issue",
	"inferred"
];
var FINDING_CLASSES = ["risk", "quality"];
var FINDING_SEVERITIES = [
	"high",
	"med",
	"low",
	"nit"
];
var FINDING_KINDS = [
	"bug",
	"race",
	"auth",
	"security",
	"api-break",
	"missing-test",
	"perf",
	"maintainability",
	"docs",
	"other"
];
var SKIP_REASONS = [
	"generated",
	"lockfile",
	"format",
	"vendored",
	"binary",
	"trivial",
	"ignored"
];
//#endregion
//#region ../lib/review.mjs
var MAX = {
	intent: 700,
	groupTitle: 100,
	groupIntent: 300,
	what: 240,
	why: 240,
	finding: 360
};
function text$1(value, max) {
	const raw = String(value ?? "").replace(/\s+/g, " ").trim();
	return raw.length > max ? `${raw.slice(0, max - 1).trimEnd()}…` : raw;
}
function oneOf(value, allowed, fallback) {
	const raw = String(value ?? "").trim().toLowerCase();
	return allowed.includes(raw) ? raw : fallback;
}
/**
* Rango de líneas de un bloque. `L40-58` es post-imagen (lo que quedó);
* `-L88-95` es pre-imagen, que es la única forma de señalar líneas borradas.
*/
function parseLineRange(value) {
	const raw = String(value ?? "").trim();
	const match = /^(-)?L?(\d+)(?:\s*[-–]\s*L?(\d+))?$/i.exec(raw);
	if (!match) return null;
	const start = Number(match[2]);
	const end = match[3] ? Number(match[3]) : start;
	return {
		side: match[1] ? "old" : "new",
		start: Math.min(start, end),
		end: Math.max(start, end)
	};
}
function formatLineRange(range) {
	if (!range) return "";
	const prefix = range.side === "old" ? "-L" : "L";
	return range.start === range.end ? `${prefix}${range.start}` : `${prefix}${range.start}-${range.end}`;
}
function countHunks(files) {
	let total = 0;
	for (const file of files || []) for (const line of String(file.diff || "").split("\n")) if (line.startsWith("@@")) total += 1;
	return total;
}
function normalizeGroups(raw) {
	const seen = /* @__PURE__ */ new Set();
	const groups = [];
	for (const item of raw || []) {
		const id = String(item?.id || "").trim();
		if (!id || seen.has(id)) continue;
		seen.add(id);
		groups.push({
			id,
			kind: oneOf(item.kind, GROUP_KINDS, "chore"),
			title: text$1(item.title, MAX.groupTitle) || `${oneOf(item.kind, GROUP_KINDS, "chore")}: cambios`,
			intent: text$1(item.intent, MAX.groupIntent)
		});
	}
	return groups;
}
function normalizeBlocks(raw, { groupIds, knownPaths }) {
	const seen = /* @__PURE__ */ new Set();
	const blocks = [];
	for (const item of raw || []) {
		const id = String(item?.id || "").trim();
		const group = String(item?.group || "").trim();
		const file = String(item?.file || "").trim();
		if (!id || seen.has(id)) continue;
		if (!groupIds.has(group)) continue;
		if (knownPaths.size && !knownPaths.has(file)) continue;
		const range = parseLineRange(item.lines);
		seen.add(id);
		blocks.push({
			id,
			group,
			file,
			lines: range ? formatLineRange(range) : text$1(item.lines, 24),
			side: range?.side || "new",
			start: range?.start ?? 0,
			end: range?.end ?? 0,
			op: oneOf(item.op, BLOCK_OPS, "mod"),
			what: text$1(item.what, MAX.what),
			why: text$1(item.why, MAX.why),
			source: oneOf(item.source, WHY_SOURCES, "inferred")
		});
	}
	blocks.sort((a, b) => a.file.localeCompare(b.file) || a.start - b.start);
	return blocks;
}
function findingKey(finding) {
	return [
		finding.file,
		finding.line ?? "",
		finding.kind,
		finding.what
	].join("|");
}
function normalizeFindings(raw, { blockIds, knownPaths }) {
	const seen = /* @__PURE__ */ new Set();
	const findings = [];
	for (const item of raw || []) {
		const file = String(item?.file || item?.path || "").trim();
		const what = text$1(item?.what || item?.title, MAX.finding);
		if (!file || !what) continue;
		if (knownPaths.size && !knownPaths.has(file)) continue;
		const cls = oneOf(item.class, FINDING_CLASSES, "risk");
		const severity = oneOf(item.severity, FINDING_SEVERITIES, "med");
		const block = String(item?.block || "").trim();
		const line = Number.isFinite(Number(item?.line)) ? Number(item.line) : null;
		const finding = {
			id: "",
			class: cls,
			severity,
			blocking: cls === "risk" && (item?.blocking === true || severity === "high"),
			kind: oneOf(item.kind, FINDING_KINDS, "other"),
			file,
			line,
			block: blockIds.has(block) ? block : "",
			what,
			fix: text$1(item.fix || item.detail, MAX.finding)
		};
		const key = findingKey(finding);
		if (seen.has(key)) continue;
		seen.add(key);
		findings.push(finding);
	}
	const rank = {
		high: 0,
		med: 1,
		low: 2,
		nit: 3
	};
	findings.sort((a, b) => Number(b.blocking) - Number(a.blocking) || (a.class === b.class ? 0 : a.class === "risk" ? -1 : 1) || rank[a.severity] - rank[b.severity] || a.file.localeCompare(b.file));
	findings.forEach((finding, i) => {
		finding.id = `f${i + 1}`;
	});
	return findings;
}
function normalizeSkipped(raw, ignored) {
	const byFile = /* @__PURE__ */ new Map();
	for (const path of ignored || []) byFile.set(String(path), {
		file: String(path),
		reason: "ignored"
	});
	for (const item of raw || []) {
		const file = String(item?.file || "").trim();
		if (!file) continue;
		byFile.set(file, {
			file,
			reason: oneOf(item.reason, SKIP_REASONS, "trivial")
		});
	}
	return [...byFile.values()];
}
/** Tema donde se dibuja el archivo: el que aporta más bloques, desempatando por orden de tema. */
function dominantGroup(blocks, path, groupOrder) {
	const tally = /* @__PURE__ */ new Map();
	for (const block of blocks) {
		if (block.file !== path) continue;
		tally.set(block.group, (tally.get(block.group) || 0) + 1);
	}
	if (!tally.size) return "";
	return [...tally.entries()].sort((a, b) => b[1] - a[1] || groupOrder.indexOf(a[0]) - groupOrder.indexOf(b[0]))[0][0];
}
/**
* Documento final: lo que dijo el modelo, saneado y cruzado contra los archivos
* reales del diff. Todo lo que no cierra se descarta acá en vez de romper la UI.
*/
function buildReview({ skeleton, payload, notes = [] }) {
	const files = skeleton.files || [];
	const knownPaths = new Set(files.map((f) => f.path));
	const groups = normalizeGroups(payload?.groups);
	const groupIds = new Set(groups.map((g) => g.id));
	const blocks = normalizeBlocks(payload?.blocks, {
		groupIds,
		knownPaths
	});
	const blockIds = new Set(blocks.map((b) => b.id));
	const findings = normalizeFindings(payload?.findings, {
		blockIds,
		knownPaths
	});
	const skipped = normalizeSkipped(payload?.skipped, skeleton.context?.ignored);
	const usedGroups = new Set(blocks.map((b) => b.group));
	const liveGroups = groups.filter((g) => usedGroups.has(g.id));
	const groupOrder = liveGroups.map((g) => g.id);
	const skippedFiles = new Set(skipped.map((s) => s.file));
	const orphans = files.filter((f) => !blocks.some((b) => b.file === f.path) && !skippedFiles.has(f.path));
	if (orphans.length) notes = [...notes, `${orphans.length} archivo(s) quedaron sin explicación del modelo.`];
	const decorated = files.map((file) => ({
		...file,
		group: dominantGroup(blocks, file.path, groupOrder)
	}));
	return {
		...skeleton,
		version: 2,
		intent: text$1(payload?.intent, MAX.intent),
		groups: liveGroups,
		blocks,
		findings,
		skipped,
		files: decorated,
		stats: {
			...skeleton.stats,
			hunks: countHunks(files)
		},
		notes,
		generatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
//#endregion
//#region src/lib/server/git-review.ts
function describeGitError(err) {
	if (err && typeof err === "object") {
		const rec = err;
		const stderr = String(rec.stderr || "").trim().split("\n").find(Boolean);
		if (stderr) return stderr;
		if (rec.message) return rec.message;
	}
	return err instanceof Error ? err.message : String(err);
}
function resolveSource(source, repo) {
	if (source === "local" || source === "url") return source;
	return looksLikeGitUrl(repo) ? "url" : "local";
}
function loadRepoInfo(source, repo) {
	if (resolveSource(source, repo) === "url") {
		const url = normalizeGitUrl(repo);
		return {
			repo: url,
			source: "url",
			...listRemoteBranches(url)
		};
	}
	const resolved = assertGitRepo(repo);
	return {
		repo: resolved,
		source: "local",
		...listBranches(resolved)
	};
}
function pickLocalFolder$1() {
	return pickFolder();
}
function resolveWorktree(source, repo, branch, base) {
	if (source === "url") return ensureRemoteWorktree(repo, branch, base);
	return assertGitRepo(repo);
}
function toReviewFile(file) {
	const changeType = file.changeType;
	const typed = changeType === "added" || changeType === "deleted" || changeType === "renamed" || changeType === "modified" ? changeType : "modified";
	return {
		path: file.path,
		oldPath: file.oldPath || void 0,
		changeType: typed,
		diff: String(file.diff ?? "").replaceAll("\0", ""),
		group: file.group ?? ""
	};
}
/**
* Contenido del archivo en la punta del branch, para rellenar en el viewer las líneas
* que el diff no trae. Devuelve null (en vez de reventar) cuando el repo no está a mano
* o el archivo es binario: ahí el viewer apaga los botones de expandir.
*/
function loadFileLines(input) {
	try {
		return showFileLines(resolveWorktree(resolveSource(input.source, input.repo), input.repo, input.branch, input.base || "develop"), input.branch, input.path);
	} catch (err) {
		console.error("[diff-review git] no se pudo leer", input.path, describeGitError(err));
		return null;
	}
}
function hydrateReviewPayload(input) {
	const skeleton = extractBranchDiff({
		repo: resolveWorktree(resolveSource(input.source, input.repo), input.repo, input.branch, input.base || "develop"),
		branch: input.branch,
		base: input.base || "develop"
	});
	const extraNotes = Array.isArray(input.payload?.notes) ? input.payload.notes.filter((n) => typeof n === "string") : [];
	const built = buildReview({
		skeleton,
		payload: input.payload,
		notes: extraNotes
	});
	const doc = {
		intent: built.intent,
		groups: built.groups,
		blocks: built.blocks,
		findings: built.findings,
		skipped: built.skipped,
		files: (built.files || []).map(toReviewFile),
		notes: built.notes || []
	};
	return JSON.parse(JSON.stringify(doc));
}
//#endregion
//#region src/lib/report/git.remote.ts
var git_remote_exports = /* @__PURE__ */ __exportAll({
	fileLines: () => fileLines,
	hydrateFromGit: () => hydrateFromGit,
	loadRepo: () => loadRepo,
	pickLocalFolder: () => pickLocalFolder
});
function fail(err) {
	const message = describeGitError(err) || "No se pudo hablar con git.";
	console.error("[diff-review git]", message, err);
	error(400, message);
}
var loadRepo = /* @__PURE__ */ query("unchecked", async (input) => {
	try {
		return loadRepoInfo(input?.source, String(input?.repo || "").trim());
	} catch (err) {
		fail(err);
	}
});
var pickLocalFolder = /* @__PURE__ */ command("unchecked", async (_input) => {
	try {
		return pickLocalFolder$1();
	} catch (err) {
		fail(err);
	}
});
/** Líneas del archivo en el branch revisado, para expandir el contexto oculto de un diff. */
var fileLines = /* @__PURE__ */ query("unchecked", async (input) => loadFileLines({
	repo: String(input?.repo || "").trim(),
	branch: String(input?.branch || "").trim(),
	base: String(input?.base || "develop").trim(),
	source: input?.source,
	path: String(input?.path || "").trim()
}));
var hydrateFromGit = /* @__PURE__ */ command("unchecked", async (input) => {
	try {
		return hydrateReviewPayload({
			repo: String(input?.repo || "").trim(),
			branch: String(input?.branch || "").trim(),
			base: String(input?.base || "develop").trim(),
			source: input?.source,
			payload: input?.payload
		});
	} catch (err) {
		fail(err);
	}
});
init_remote_functions(git_remote_exports, "src/lib/report/git.remote.ts", "1g4ayag");
for (const [name, fn] of Object.entries(git_remote_exports)) {
	fn.__.id = "1g4ayag/" + name;
	fn.__.name = name;
}
//#endregion
export { loadRepo as n, git_remote_exports as t };
