//#region src/lib/theme.ts
var KEY = "diff-review:theme";
function loadTheme() {
	try {
		return localStorage.getItem(KEY) === "light" ? "light" : "dark";
	} catch {
		return "dark";
	}
}
function applyTheme(theme) {
	document.documentElement.setAttribute("data-theme", theme);
}
//#endregion
export { loadTheme as n, applyTheme as t };
