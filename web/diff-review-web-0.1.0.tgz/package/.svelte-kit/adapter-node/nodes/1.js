

export const index = 1;
export const imports = ["_app/immutable/nodes/1.BLb4VEt5.js","_app/immutable/chunks/Dur-vdUf.js","_app/immutable/chunks/G1xn5Qsm.js","_app/immutable/chunks/tYeNsyIK.js"];
export const stylesheets = [];
export const fonts = [];
