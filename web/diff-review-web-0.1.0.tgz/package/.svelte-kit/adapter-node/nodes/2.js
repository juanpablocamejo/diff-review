

export const index = 2;
export const imports = ["_app/immutable/nodes/2.BwS--VyF.js","_app/immutable/chunks/Dur-vdUf.js","_app/immutable/chunks/G1xn5Qsm.js","_app/immutable/chunks/C_FyVAEP.js","_app/immutable/chunks/tYeNsyIK.js","_app/immutable/chunks/BZfQ9INH.js"];
export const stylesheets = ["_app/immutable/assets/ThemeToggle.DcT79vPK.css","_app/immutable/assets/2.jTZ9J3Q4.css"];
export const fonts = [];
