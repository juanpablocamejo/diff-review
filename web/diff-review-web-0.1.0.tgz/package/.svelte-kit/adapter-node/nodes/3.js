

export const index = 3;
export const imports = ["_app/immutable/nodes/3.DrQdp27l.js","_app/immutable/chunks/Dur-vdUf.js","_app/immutable/chunks/G1xn5Qsm.js","_app/immutable/chunks/C_FyVAEP.js","_app/immutable/chunks/tYeNsyIK.js","_app/immutable/chunks/BZfQ9INH.js"];
export const stylesheets = ["_app/immutable/assets/ThemeToggle.DcT79vPK.css","_app/immutable/assets/3.B3p6DeAQ.css"];
export const fonts = [];
