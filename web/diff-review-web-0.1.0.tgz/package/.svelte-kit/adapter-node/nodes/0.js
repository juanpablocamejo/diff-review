

export const index = 0;
export const universal = {
  "ssr": false
};
export const universal_id = "src/routes/+layout.ts";
export const imports = ["_app/immutable/nodes/0.Bk48XksT.js","_app/immutable/chunks/Dur-vdUf.js","_app/immutable/chunks/tYeNsyIK.js","_app/immutable/chunks/BZfQ9INH.js"];
export const stylesheets = ["_app/immutable/assets/0.cbfpp8K5.css"];
export const fonts = [];
